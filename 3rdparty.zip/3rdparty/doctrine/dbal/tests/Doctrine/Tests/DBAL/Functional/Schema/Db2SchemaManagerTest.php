<?php

namespace Doctrine\Tests\DBAL\Functional\Schema;

use Doctrine\DBAL\Schema;

require_once __DIR__ . '/../../../TestInit.php';

class Db2SchemaManagerTest extends SchemaManagerFunctionalTestCase
{

}