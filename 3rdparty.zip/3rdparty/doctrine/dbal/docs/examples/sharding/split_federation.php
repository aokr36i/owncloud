<?php
// split_federation.php
require_once 'bootstrap.php';

$shardManager->splitFederation(60);
