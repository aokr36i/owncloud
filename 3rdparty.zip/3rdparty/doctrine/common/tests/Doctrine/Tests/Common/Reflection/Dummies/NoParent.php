<?php

namespace Doctrine\Tests\Common\Reflection\Dummies;

class NoParent
{
    public $test;
}
