<?php

namespace {
	use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Secure;
}

namespace {
	use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Route;
	use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Template;

	class GlobalNamespacesPerFileWithClassAsLast {}
}