<?php

namespace Doctrine\Tests\Common\Reflection;

class FullyClassifiedParent extends \Doctrine\Tests\Common\Reflection\NoParent
{
}
